<?php

namespace photon\tests\small\simple;

function just_testing()
{
    return 'OK';
}
